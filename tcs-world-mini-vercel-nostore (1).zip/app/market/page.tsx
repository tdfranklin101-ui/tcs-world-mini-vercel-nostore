export const revalidate = '0';

'use client';

import { useEffect, useState } from 'react';

export const dynamic = 'force-dynamic';
export const fetchCache = "force-no-store";

type Item = { id: string; title: string; description: string; rays_price: number; };

export default function MarketPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const r = await fetch('/api/market/list');
      const data = await r.json();
      setItems(data ?? []);
      setLoading(false);
    })();
  }, []);

  return (
    <main className="space-y-6">
      <div className="card">
        <h2 className="text-xl font-semibold mb-4">Market</h2>
        {loading ? <div>Loading…</div> : (
          <ul className="space-y-3">
            {items.map((it) => (
              <li key={it.id} className="p-3 rounded-xl bg-white/5 border border-white/10">
                <div className="font-semibold">{it.title}</div>
                <div className="text-sm text-white/75">{it.description}</div>
                <div className="mt-2 text-solar-100">
                  <span className="font-bold">{it.rays_price} Rays</span>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </main>
  );
}
