export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import { supabaseService } from '@/lib/supabase-server';
import { getOrCreateWalletId } from '@/lib/wallet-id';

export const runtime = 'nodejs';

// Adds a small daily grant in kWh; idempotent per day.
export async function GET() {
  const wallet = getOrCreateWalletId();
  const today = new Date().toISOString().slice(0,10);
  const daily_kwh = 1.0; // ~0.0002 Solar per day (example)

  try {
    const sb = supabaseService();
    // Ensure wallet row exists
    await sb.from('tcs_balances').upsert({ wallet_id: wallet, kwh: 0 }, { onConflict: 'wallet_id' });

    // Insert daily ledger row if not already present
    const { data: existing } = await sb
      .from('tcs_grants')
      .select('id')
      .eq('wallet_id', wallet)
      .eq('grant_day', today)
      .limit(1);
    if (!existing || existing.length === 0) {
      await sb.from('tcs_grants').insert({ wallet_id: wallet, grant_day: today, kwh: daily_kwh });
      await sb.rpc('tcs_increment_balance', { p_wallet_id: wallet, p_kwh: daily_kwh });
    }

    return NextResponse.json({ ok: true, wallet, granted: daily_kwh }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (e: any) {
    // Soft success in submission context
    return NextResponse.json({ ok: true, wallet, granted: 0 }, { headers: { 'Cache-Control': 'no-store' } });
  }
}
