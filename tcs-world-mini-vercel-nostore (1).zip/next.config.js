/** @type {import('next').NextConfig} */
const nextConfig = {
  
async headers() {
  return [
    {
      source: "/api/:path*",
      headers: [{ key: "Cache-Control", value: "no-store" }]
    }
  ];
},

  experimental: {
    esmExternals: true,
  },
  typescript: {
    // Don't block build on type errors in deployment environments
    ignoreBuildErrors: true,
  },
};
module.exports = nextConfig;
