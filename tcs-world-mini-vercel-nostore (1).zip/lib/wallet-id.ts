import { cookies } from 'next/headers';
import { randomUUID } from 'crypto';

const COOKIE = 'tcs_wallet';

export function getOrCreateWalletId(): string {
  const c = cookies();
  let id = c.get(COOKIE)?.value;
  if (!id) {
    id = randomUUID();
    // set for ~1 year
    c.set(COOKIE, id, { httpOnly: false, secure: true, sameSite: 'lax', maxAge: 60 * 60 * 24 * 365 });
  }
  return id;
}
